<?php

/** Comentado para LAravel */
require_once $datadash->path . "app/DatadashController.php";
require_once $datadash->path . "app/datadash.routes.php";
/** comentar hasta aqui para laravel */
require_once $datadash->path . "app/views/view-dd-estadistica.blade.php";
require_once $datadash->path . "app/views/view-dd-dash-public.blade.php";
require_once $datadash->path . "app/views/view-dd-control-panel.blade.php";

require_once $datadash->path . "app/views/view-dd-indicadores.blade.php";

require_once $datadash->path . "app/datadash.shortcodes.php";


