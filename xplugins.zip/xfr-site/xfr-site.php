<?php
/*
Plugin Name: xfr-site
Plugin URI: 
Description: Configuraciones del sitio
Version: 1.5
Author: Marce 
Author URI: 
Licence: GPL2
Text Domain: XYZ-Cod
Doman Path: /languages/
*/


// $xyz_site = (object)[];
// $xyz_site->core_classname = 'XYZ_Core';
// $xyz_site->core_classfile = WP_PLUGIN_DIR . '/xyz-core/xyz-core.php';
// $xyz_site->url            = plugin_dir_url(__FILE__);
// $xyz_site->path           = plugin_dir_path(__FILE__);

// if (is_admin())
//     return false;

// if (!class_exists($register->core_classname)) {
//     require_once $register->core_classfile;
// }

// /** LIBRERIAS PROPIAS */
require_once 'xcod-site.php';
require_once 'xcod-shortcodes.php';


/* Al activar el plugin se activa esta funcion */
// xcod_plugin_activate(__FILE__);



